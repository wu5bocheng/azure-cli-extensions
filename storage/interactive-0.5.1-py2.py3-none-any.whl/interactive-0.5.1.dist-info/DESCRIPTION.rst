# Azure CLI Interactive Mode



## The interactive mode for Microsoft Azure CLI (Command Line Interface)



- Recommend Commands and Scenarios Based on Previous Commands

- Search for Scenarios

- Value Completion in Scenario Mode

- Interactive Tutorials

- Lightweight Drop Down Completions 

- Auto Cached Suggestions 

- Dynamic parameter completion 

- Defaulting scopes of commands

- On the fly descriptions of the commands AND parameters 

- On the fly examples of how to utilize each command 

- Query the previous command

- Navigation of example pane 

- Optional layout configurations 

- Optional "az" component 

- Fun Colors 



![Overview](docs/shell.gif)





## Updates



Azure CLI Shell is now Azure CLI Interactive Mode. To get updates, install the newest version of the CLI! First, uninstall the deprecated shell applications with:



```bash

   $ pip uninstall azure-cli-shell

```



## Running



To start the application



```bash

   $ az interactive

```



Then type your commands and hit [Enter]



To use commands outside the application



```bash

   $ #[command]

```



To Search through the last command as json

jmespath format for querying



```bash

   $ ? [param]

```



*Note: Only if the previous command dumps out json, e.g. vm list*



To only see the commands for a command



```bash

   $ %% [top-level command] [sub-level command] etc

```



To undefault a value



```bash

   $ %% ..

```



To Search for a scenario



```bash

   $ /[keywords]

```



## Use Examples



Type a command, for example:



```bash

   $ vm create

```



Look at the examples



*Scroll through the pane with Control Y for up and Control N for down #*



Pick the example you want with:



```bash

   $ vm create :: [Example Number]

```



## Clear History



```bash

   $ clear-history

```



Only clears the appended suggestion when you restart the interactive shell





## Clear Screen



```bash

   $ clear

```





## Change colors



```bash

   $ az interactive --styles [option]

```



The color option will be saved.



# Intelligent AZ Interactive (Revolutionary Change)

## Recommendation



We have integrated the cli recommendation to make the completion ability more intelligent and provide the scenario completion. This is a revolutionary change. Users can enable or disable the recommendation feature by running the following commands:



```

$ az config set interactive.enable_recommender=True # Default, try the new recommendation feature

$ az config set interactive.enable_recommender=False # Disable the recommendation feature

```



### Command Recommendation



Command recommendation uses an intelligent algorithm to suggest the most relevant and frequently used command for the user based on their historical command inputs. By analyzing the user's input history and matching it with the highest relevant commands, Intelligent Az Interactive can assist Azure CLI beginners in making quick and informed decisions, saving them time and effort.



The command recommendation feature can also be a good way to broaden users' knowledge boundaries and help them recognize and learn commands that are related to their common commands but never used before.



### Scenario Identification



Scenario identification is another powerful feature that automatically recognizes the user's current scenario and recommends a set of commands that are most relevant to the user's needs. This feature is based on our extensive database of over 600+ business scenarios, which cover a wide range of use cases across various scenes. By analyzing the user's input history, Intelligent Az Interactive can identify the relevant scenario and suggest the most appropriate command set, helping new CLI users to quickly accomplish their tasks with confidence and ease.



## Search for Scenarios



We have added the ability to help users search for scenarios based on keywords. When the user enters some keywords or descriptions, we will recommend the scenarios that are most likely to be used based on the keywords and descriptions of the functions the user wants to implement.



```

$ az interactive // initialize the az interactive

$ /connect a mongodb to web app // Search for scenario by starting with / and entering keywords

>>  output

[1] Connect an app to MongoDB (Cosmos DB). (5 Commands)

Connect an app to MongoDB (Cosmos DB).



[2] Tutorial to create and connect Web App to Azure Database for MySQL Flexible Server in a virtual network (6 Commands)

Tutorial to create and connect Web App to Azure Database for MySQL Flexible Server in a virtual network



[3] Connect an app to SQL Database. (7 Commands)

Connect an app to SQL Database.



[4] Connect an app to a storage account. (5 Commands)

Connect an app to a storage account.



[5] Deploy an ASP.NET Core web app to Azure App Service and connect to an Azure SQL Database. (8 Commands)

Deploy an ASP.NET Core web app to Azure App Service and connect to an Azure SQL Database.



 ? Please select your option (if none, enter 0):

 $ 1 // Select the scenario you want to use

```



## Loading Bar



The loading bar is a feature that we have implemented to provide users with a more stable and predictable experience while using our platform. Its primary function is to prevent command parameter detection errors that may occur due to incomplete loading. By displaying the progress of initialization through the loading bar, users can be assured that the initialization process is ongoing and they can expect to see a fully loaded interface once the bar reaches 100%.



Additionally, the loading bar helps prevent user interface lagging or freezing due to insufficient memory. By preloading the necessary resources and data, users can avoid encountering these issues when inputting commands.



The loading bar is an essential tool that improves the user experience by ensuring that all necessary components are loaded before usage, thereby reducing the risk of encountering errors and providing a smoother, more stable platform.



Please refer to the following gif to see the loading bar in action:



<div  align="center">    

<img src="docs/loading_bar.gif" width = "400" height = "150" alt="loading_bar" align=center>

</div>





## Value Completion in Scenarios



We added a completion mechanism for param value in scenarios to improve the completion ability of param value in

scenarios. In multiple commands of the same scenario, once the user enters a param value, we store the value entered by

the user based on the scenario sample value and some special global params, and automatically recommend the completion

of these param values in subsequent commands.



## Telemetry Feedback Optimization



To collect data and facilitate the optimization and tuning of the cli recommendation model, we have optimized the

telemetry feedback function. We have added `CLIRecommendation` to the `properties` of telemetry feedback. For details,

please refer

to [cli-recommendation](https://github.com/hackathon-cli-recommendation/cli-recommendation/blob/master/Docs/feedback_design.md).



.. :changelog:



Release History

===============

0.5.1

+++++

* integrate with chatgpt



0.5.0

+++++

* Support command recommendations that predicts the next commands users might need.

* Support scenario recommendations to help users complete the complex scenarios more smoothly and simply.

* Support new config `az config set interactive.enable_recommender=False` to disable these new recommenders.

* Fix display offset in toolbar.

* Add loading bar to avoid command execution errors caused by uncompleted command loading and param update. User can use CTRL+C to cancel the loading bar.

* Update telemetry feedback function and add 'CLIRecommendation' property. (Details: https://github.com/hackathon-cli-recommendation/cli-recommendation/blob/master/Docs/feedback_design.md)

* Add value completion mechanism for param value in scenarios

* Support searching ability for scenarios

* Optimize param completion mechanism to recommend one parameter at a time

* Fix some small bugs

* Remove README.rst and modified setup file

* Import styled text print from azure-cli-core.style



0.4.6

+++++

* Compatible with argcomplete 2.0.0



0.4.5

+++++

* Fix #17740: `az interactive` fails with `progress_patch() got an unexpected keyword argument 'det'`



0.4.4

+++++

* Remove dependency of azure-cli-core's ENV_ADDITIONAL_USER_AGENT



0.4.3

+++++

* Fix config problem in interactive



0.4.2

+++++

* Update to remain compatible with azure-cli 2.0.62.



0.4.1

+++++

* Remove command registration, rely on module to be called.



0.4.0

+++++

* Converted from interactive module to extension.



0.3.31

++++++

* Ensure global subscription parameter appears in parameters.



0.3.30

++++++

* Fix error found on windows where commands fail to run properly.



0.3.29

++++++

* Fix command loading problem in interactive that was caused by deprecated objects.



0.3.28

++++++

* Minor fixes



0.3.27

++++++

* Minor fixes



0.3.26

++++++

* Minor fixes



0.3.25

++++++

* Update PyYAML dependency to 4.2b4



0.3.24

++++++

* Minor fixes



0.3.23

++++++

* Minor fixes



0.3.22

++++++

* Fix dependency versions.



0.3.21

++++++

* Mute logging from parser for completions.

* Made interactive more resistant to stale/corrupted help caches.



0.3.20

++++++

* Allow interactive completers to function with positional arguments.

* More user-friendly output when users type '\'.

* Fix completions for parameters with no help.

* Fix descriptions for command-groups.



0.3.19

++++++

* Stops completions upon unrecognized commands.

* Add event hooks before and after command subtree is created.

* Allow completions for --ids parameters.

* `sdist` is now compatible with wheel 0.31.0



0.3.18

++++++

* Completions kick in as soon as command table loading is done.

* Fix bug with using `--style` parameter.

* Interactive lexer instantiated after command table dump if missing.

* Improvements to completer support.



0.3.17

++++++

* Persist history across different sessions

* Fixed history while in scope

* Updates to interactive telemetry

* Fixed progress meter for long running operations

* Completions more robust to command table exceptions



0.3.16

++++++

* Fix issue where user is prompted to login when using interactive mode in Cloud Shell.

* Fixed regression with missing parameter completions.



0.3.15

++++++

* Fixed issue where command option completions no longer appeared.



0.3.14

++++++

* Clean up unused test files



0.3.13

++++++

* Fix issue where interactive would not start on Python 2.

* Fix errors on start up

* Fix some commands not running in interactive mode



0.3.12

++++++

* Update for CLI core changes.



0.3.11

++++++

* minor fixes



0.3.10 (2017-09-22)

+++++++++++++++++++

* minor fixes



0.3.9 (2017-08-31)

++++++++++++++++++

* minor fixes



0.3.8 (2017-08-28)

++++++++++++++++++

* minor fixes



0.3.7 (2017-07-27)

++++++++++++++++++



* Improves the start up time by using cached commands





0.3.7 (2017-07-27)

++++++++++++++++++



* Increase test coverage



0.3.5 (2017-06-21)

++++++++++++++++++



* Enhance the '?' gesture to also inject into the next command



0.3.4 (2017-06-13)

++++++++++++++++++



* Fixes Interactive errors with the profile 2017-03-09-profile-preview (#3587)

* Allows '--version' as a parameter for interactive mode (#3645)

* Stop Interactive Mode from Throwing errors from Validation completions (#3570)

* Progress Reporting for template deployments (#3510)



0.3.3 (2017-05-30)

++++++++++++++++++



* --progress flag

* Removed --debug and --verbose from completions



0.3.2 (2017-05-18)

++++++++++++++++++



* Bug fixes.

* Remove 'interactive' from completions (#3324)



0.3.1 (2017-05-09)

++++++++++++++++++



* Add link to blog in ‘az interactive —help’ (#3252)





0.3.0 (2017-05-05)

++++++++++++++++++



* Integrate interactive into az

* Colors Options

* Rename 'shell' => 'interactive'





0.2.1

++++++++++++++++++



* CLI Performance changes integrated





0.2.0

++++++++++++++++++



* Public Preview release





0.1.1

++++++++++++++++++



* Preview release

